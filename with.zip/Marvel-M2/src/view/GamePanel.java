package view;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import model.world.*;
import engine.*;
public class GamePanel extends JPanel implements KeyListener,ActionListener{
	private GameConsole controller;
    private JPanel panel1= new JPanel();
    private JButton[][]board;


   public  GamePanel(GameConsole controller)	{
	   this.controller = controller;
	   this.setLayout(null);
	   
	   board= new JButton[5][5];
	   
	   
	   panel1.setLayout(new GridLayout(5,5));
	   panel1.setBounds(480,160,500,500);
	   this.add(panel1);
	  
	  
	   
	   
	   Object[][]boa = controller.getGame().getBoard();
	   
	   for(int i=0;i<5;i++) {
		   for(int j=0;j<5;j++) {
			   board[i][j]= new JButton();
			   board[i][j].setFont(new Font("Serif",Font.PLAIN,11));
			   board[i][j].addActionListener(this);
			   panel1.add(board[i][j]);
			   
			   
			   if(boa[i][j]instanceof Champion) {
				   Champion c=(Champion)boa[i][j];
				   board[i][j].setText(c.getName());
				   if(controller.getGame().getFirstPlayer().getTeam().contains(c)) {
					   
					   board[i][j].setBackground(Color.RED);
					   board[i][j].setForeground(Color.WHITE);
					   
					   
				   }
				   else if(controller.getGame().getSecondPlayer().getTeam().contains(c)) {
					   board[i][j].setBackground(Color.BLUE);
					   board[i][j].setForeground(Color.WHITE);
					   
				   }
				   
			   }
			   else if(boa[i][j]instanceof Cover) {
				   Cover c=(Cover)boa[i][j];
				   board[i][j]= new JButton(c.getCurrentHP()+"");
				   board[i][j].setBackground(Color.BLACK);
				   board[i][j].setForeground(Color.WHITE);
					   
				   
			   }
			   
		
		   
	   }
	   }
	  
	
}
	
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}}
